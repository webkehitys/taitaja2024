<?php

use Illuminate\Support\Facades\Route;

/**
 * Redirect from /
 */
Route::get('/', fn () => redirect('/admin'));

/**
 * Guest Routes
 */
Route::group(['middleware' => 'guest'], function () {
    Route::view('login', 'auth.login')->name('login');
    Route::post('login', [\App\Http\Controllers\AuthController::class, 'login']);
});

/**
 * Protected routes
 */
Route::group(['middleware' => 'auth'], function () {
    // Logout
   Route::post('logout', [\App\Http\Controllers\AuthController::class, 'logout'])->name('logout');

   // Intranet entrypoint
   Route::get('admin', [\App\Http\Controllers\AdminController::class, 'index']);

    /**
     * Profile
     */
    Route::put('profile', [\App\Http\Controllers\ProfileController::class, 'update']);
    Route::put('profile/games/{game}', [\App\Http\Controllers\ProfileController::class, 'updateGame']);
    Route::get('profile/games/{game}/scores/{score}', [\App\Http\Controllers\ProfileController::class, 'editGameScore']);
    Route::put('profile/games/{game}/scores/{score}', [\App\Http\Controllers\ProfileController::class, 'updateGameScore']);
    Route::get('profile/games/{game}/scores', [\App\Http\Controllers\ProfileController::class, 'createGameScore']);
    Route::post('profile/games/{game}/scores', [\App\Http\Controllers\ProfileController::class, 'storeGameScore']);

    /**
    * Admin only
    */
    Route::group(['middleware' => 'admin'], function () {
        Route::resource('users', \App\Http\Controllers\UserController::class)->except('index', 'show');
        Route::resource('games', \App\Http\Controllers\GameController::class)->except('index', 'show', 'delete');
        Route::get('games/{game}/users', [\App\Http\Controllers\GameController::class, 'users']);
        Route::post('games/{game}/users', [\App\Http\Controllers\GameController::class, 'addUser']);
    });
});
