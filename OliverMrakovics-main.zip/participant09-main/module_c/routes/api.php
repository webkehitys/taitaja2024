<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::post('games/{game}/score', [\App\Http\Controllers\Api\ScoreController::class, 'store']);
