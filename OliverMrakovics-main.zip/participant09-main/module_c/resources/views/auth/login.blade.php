@extends('layout.main')
@section('content')
    <div class="auth-main">
        <form class="auth-card" method="POST">
            @csrf

            <h1>Login</h1>

            @error('auth')
            <div class="alert">{{$message}}</div>
            @enderror

            {{-- Input--}}
            <div class="input-wrapper">
                <input name="username" type="text" placeholder="Username" value="{{old('username')}}" required />
                @error('username')
                <span class="input-error">{{$message}}</span>
                @enderror
            </div>

            {{-- Password--}}
            <div class="input-wrapper">
                <input name="password" type="password" placeholder="Password" required />
                @error('password')
                <span class="input-error">{{$message}}</span>
                @enderror
            </div>

            <button class="btn">Login</button>
        </form>
    </div>
@endsection
