@extends('layout.main')
@section('content')
    <x-header />
    <div class="auth-main" style="height: calc(100vh - 120px)">
        <form class="auth-card" method="POST" action="/users/{{$user->id}}">
            @csrf
            @method('PUT')

            <h2>Edit password: {{$user->username}}</h2>

            {{-- Password--}}
            <div class="input-wrapper">
                <input name="password" type="password" placeholder="Password" required />
                @error('password')
                <span class="input-error">{{$message}}</span>
                @enderror
            </div>

            <button class="btn">Save</button>
        </form>
    </div>
@endsection
