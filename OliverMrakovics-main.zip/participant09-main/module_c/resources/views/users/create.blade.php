@extends('layout.main')
@section('content')
    <x-header />
    <div class="auth-main" style="height: calc(100vh - 120px)">
        <form class="auth-card" method="POST" action="/users">
            @csrf

            <h1>Create user</h1>

            {{-- Input--}}
            <div class="input-wrapper">
                <input name="username" type="text" placeholder="Username" value="{{old('username')}}" required />
                @error('username')
                <span class="input-error">{{$message}}</span>
                @enderror
            </div>

            <button class="btn">Submit</button>
        </form>
    </div>
@endsection
