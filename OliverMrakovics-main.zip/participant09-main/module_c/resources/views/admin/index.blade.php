@extends('layout.main')
@section('content')
    <x-header />
    <div class="main">
        <h2>Users</h2>
        <a href="/users/create" class="btn" style="align-self: flex-start">New User</a>

        {{--  Users table  --}}
        <table>
            <thead>
            <tr>
                <th>Username</th>
                <th>Created At</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
            </thead>
            @foreach($users as $user)
                <tr>
                    <td>{{$user->username}}</td>
                    <td>{{$user->created_at}}</td>
                    <td>{{$user->admin ? 'ADMIN' : "PLAYER"}}</td>
                    <td>
                        <a href="/users/{{$user->id}}/edit" class="btn" style="display: inline-flex; margin-right: 4px;">Edit</a>

                        <form method="POST" action="/users/{{$user->id}}" style="display: inline-flex">
                            @csrf
                            @method('DELETE')
                            <button class="btn" @if($user->id == auth()->user()->id) disabled @endif>Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </table>

        <hr />

        <h2>Games</h2>
        <a href="/games/create" class="btn" style="align-self: flex-start">New Game</a>

        {{--  Games table  --}}

        <table>
            <thead>
            <tr>
                <th>Title</th>
                <th>Image</th>
                <th>Number of Results Displayed</th>
                <th>Created at</th>
                <th>Actions</th>
            </tr>
            </thead>
            @foreach($games as $game)
                <tr>
                    <td>{{$game->title}}</td>
                    <td>
                        @if($game->image)
                            <img src="{{$game->image}}" alt="{{$game->title}}" style="height: 48px" />
                        @else
                            -
                        @endif
                    </td>
                    <td>{{$game->number_of_results}}</td>
                    <td>{{$game->added_to_hall_of_fame}}</td>
                    <td>
                        <a href="/games/{{$game->id}}/edit" class="btn" style="display: inline-flex; margin-right: 4px;">Edit</a>
                        <a href="/games/{{$game->id}}/users" class="btn" style="display: inline-flex">Manage users</a>
                    </td>
                </tr>
            @endforeach
        </table>
    </div>
@endsection
