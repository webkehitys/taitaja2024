@extends('layout.main')
@section('content')
    <x-header />
    <div class="auth-main" style="height: calc(100vh - 120px)">
        <form class="auth-card" method="POST" action="/games" enctype="multipart/form-data">
            @csrf

            <h1>Create game</h1>

            {{-- Input--}}
            <div class="input-wrapper">
                <input name="title" type="text" placeholder="Title" value="{{old('title')}}" />
                @error('title')
                <span class="input-error">{{$message}}</span>
                @enderror
            </div>

            {{-- Input--}}
            <div class="input-wrapper">
                <label for="image">Image</label>
                <input name="image" id="image" type="file" accept="image/png, image/jpeg, image/png" placeholder="Image" />
                @error('image')
                <span class="input-error">{{$message}}</span>
                @enderror
            </div>

            {{-- Input--}}
            <div class="input-wrapper">
                <input name="number_of_results" type="text" placeholder="Number of results displayed" value="{{old('number_of_results')}}" />
                @error('number_of_results')
                <span class="input-error">{{$message}}</span>
                @enderror
            </div>

            <div style="border-left: 5px solid #ccc;padding-left: 8px">Note: The created at timestamp is generated automatically, but you can change it in the future.</div>

            <button class="btn">Submit</button>
        </form>
    </div>
@endsection
