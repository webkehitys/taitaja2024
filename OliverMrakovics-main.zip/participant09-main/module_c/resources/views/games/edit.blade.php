@extends('layout.main')
@section('content')
    <x-header />
    <div class="auth-main" style="height: calc(100vh - 120px)">
        <form class="auth-card" method="POST" action="/games/{{$game->id}}" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <h1>Edit game</h1>

            {{-- Input--}}
            <div class="input-wrapper">
                <label for="title">Title</label>
                <input name="title" id="title" type="text" placeholder="Title" value="{{old('title', $game->title)}}" />
                @error('title')
                <span class="input-error">{{$message}}</span>
                @enderror
            </div>

            {{-- Input--}}
            <div class="input-wrapper">
                <label for="image">Image</label>
                <input name="image" id="image" type="file" accept="image/png, image/jpeg, image/png" placeholder="Image" value="{{$game->title}}" />
                <span style="font-size: .8rem">If you do not provide a new image here, the previously uploaded image will not be removed.</span>
                @error('image')
                <span class="input-error">{{$message}}</span>
                @enderror
            </div>

            {{-- Input--}}
            <div class="input-wrapper">
                <label for="number_of_results">Number of results displayed</label>
                <input name="number_of_results" id="number_of_results" type="text" placeholder="Number of results displayed" value="{{old('number_of_results', $game->number_of_results)}}" />
                @error('number_of_results')
                <span class="input-error">{{$message}}</span>
                @enderror
            </div>

            {{-- Input--}}
            <div class="input-wrapper">
                <label id="added_to_hall_of_fame">Added to hall of fame</label>
                <input name="added_to_hall_of_fame" id="added_to_hall_of_fame" type="datetime-local" placeholder="Added to hall of fame" value="{{old('added_to_hall_of_fame', $game->added_to_hall_of_fame)}}" />
                @error('added_to_hall_of_fame')
                <span class="input-error">{{$message}}</span>
                @enderror
            </div>

            <button class="btn">Submit</button>
        </form>
    </div>
@endsection
