@extends('layout.main')
@section('content')
    <x-header />
    <div class="auth-main" style="height: calc(100vh - 120px)">
        <form class="auth-card" method="POST" action="/games/{{$game->id}}/users" enctype="multipart/form-data" style="width: min(500px, 100%)">
            @csrf

            <h2>Users</h2>
            {{--  Users table  --}}
            <table>
                <thead>
                <tr>
                    <th>Username</th>
                    <th>Role</th>
                </tr>
                </thead>
                @foreach($users as $user)
                    <tr>
                        <td>{{$user->username}}</td>
                        <td>{{$user->admin ? 'ADMIN' : "PLAYER"}}</td>
                    </tr>
                @endforeach
            </table>

            <hr />

            <h2>Add user to {{$game->title}}</h2>

            {{-- Input--}}
            <div class="input-wrapper">
                <input name="username" type="text" placeholder="Username" value="{{old('username')}}" />
                @error('username')
                <span class="input-error">{{$message}}</span>
                @enderror
            </div>

            <button class="btn" style="align-self: flex-start">Submit</button>
        </form>
    </div>
@endsection
