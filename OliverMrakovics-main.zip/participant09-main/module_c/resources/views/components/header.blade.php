<header>
    <a href="/admin" style="color: black">
        <h6>Intranet</h6>
    </a>

    <nav>
        <span>Hello, <b>{{auth()->user()->username}}</b>!</span>
        <form method="POST" action="/logout">
            @csrf
            <button class="btn">Logout</button>
        </form>
    </nav>
</header>
