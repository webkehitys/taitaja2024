@extends('layout.main')
@section('content')
    <x-header/>
    <div class="main">
        <form class="auth-card" method="POST" action="/profile">
            @csrf
            @method('PUT')

            <h2>Edit my password</h2>

            {{-- Password--}}
            <div class="input-wrapper">
                <input name="password" type="password" placeholder="Password" required/>
                @error('password')
                <span class="input-error">{{$message}}</span>
                @enderror
            </div>

            <button class="btn">Update</button>
        </form>

        <hr/>

        <h2>My Games</h2>

        @foreach($games as $game)
            <div style="display: flex; align-items: flex-start; gap: 1rem; border: 1px solid #aaa; padding: 1rem">
                <form class="auth-card" method="POST" action="/profile/games/{{$game->id}}" enctype="multipart/form-data" style="flex-shrink: 0">
                    @csrf
                    @method('PUT')

                    <h3>Game: {{$game->title}}</h3>

                    <div class="input-wrapper">
                        <label>Number of results displayed</label>
                        <input name="number_of_results" type="text" placeholder="Number of results displayed"
                               value="{{old('number_of_results', $game->number_of_results)}}"/>
                        @error('number_of_results')
                        <span class="input-error">{{$message}}</span>
                        @enderror
                    </div>

                    <button class="btn">Save</button>
                </form>
                <table>
                    <thead>
                    <tr>
                        <th>Username</th>
                        <th>Score</th>
                        <th>Timestamp</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    @foreach($game->scores as $score)
                        <tr>
                            <td>{{$score->username}}</td>
                            <td>{{$score->score}}</td>
                            <td>{{$score->created_at}}</td>
                            <td>
                                <a href="/profile/games/{{$game->id}}/scores/{{$score->id}}" class="btn">Edit</a>
                            </td>
                        </tr>
                    @endforeach
                </table>
                <a href="/profile/games/{{$game->id}}/scores" class="btn" style="text-align: center">Create new score</a>
            </div>
        @endforeach
    </div>
@endsection
