@extends('layout.main')
@section('content')
    <x-header />
    <div class="auth-main" style="height: calc(100vh - 120px)">
        <form class="auth-card" method="POST" action="/profile/games/{{$game->id}}/scores/{{$score->id}}">
            @csrf
            @method('PUT')

            <h2>Edit score</h2>

            {{-- Input--}}
            <div class="input-wrapper">
                <label for="username">Username</label>
                <input name="username" id="username" type="text" placeholder="Username" value="{{old('username', $score->username)}}" />
                @error('username')
                <span class="input-error">{{$message}}</span>
                @enderror
            </div>

            {{-- Input--}}
            <div class="input-wrapper">
                <label for="score">Score</label>
                <input name="score" id="score" type="text" placeholder="Score" value="{{old('score', $score->score)}}" />
                @error('score')
                <span class="input-error">{{$message}}</span>
                @enderror
            </div>

            <button class="btn">Save</button>
        </form>
    </div>
@endsection
