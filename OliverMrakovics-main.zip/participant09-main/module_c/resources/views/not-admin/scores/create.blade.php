@extends('layout.main')
@section('content')
    <x-header />
    <div class="auth-main" style="height: calc(100vh - 120px)">
        <form class="auth-card" method="POST" action="/profile/games/{{$game->id}}/scores">
            @csrf

            <h2>Create score</h2>

            {{-- Input--}}
            <div class="input-wrapper">
                <input name="username" type="text" placeholder="Username" value="{{old('username')}}" />
                @error('username')
                <span class="input-error">{{$message}}</span>
                @enderror
            </div>

            {{-- Input--}}
            <div class="input-wrapper">
                <input name="score" type="text" placeholder="Score" value="{{old('score')}}" />
                @error('score')
                <span class="input-error">{{$message}}</span>
                @enderror
            </div>

            <button class="btn">Submit</button>
        </form>
    </div>
@endsection
