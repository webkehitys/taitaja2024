<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use App\Models\Game;
use App\Models\Score;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Create two users
        User::create(['username' => 'admin', 'password' => 'taitaja2024', 'admin' => true]);
        $user = User::create(['username' => 'user', 'password' => 'taitaja2024']);

        // Create a game
        $game = Game::create(['title' => 'Oliver Game', 'image' => '/game-img.jpeg', 'number_of_results' => 20]);

        DB::table('game_users')->insert(['game_id' => $game->id, 'user_id' => $user->id]);
        Score::create(['username' => 'Oliver', 'score' => 10000, 'game_id' => $game->id]);
    }
}
