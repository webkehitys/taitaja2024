<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreGameScoreRequest;
use App\Http\Requests\UpdateProfileGameRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Models\Game;
use App\Models\Score;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class ProfileController extends Controller
{
    /**
     * Update profile
     */
    public function update(UpdateUserRequest $request)
    {
        // Update the user password and redirect
        auth()->user()->update($request->validated());
        return redirect('/admin');
    }

    /**
     * Update game
     */
    public function updateGame(UpdateProfileGameRequest $request, Game $game)
    {
        // Check whether the user has access to the game
        if(!DB::table('game_users')->where('game_id', $game->id)->where('user_id', auth()->user()->id)->exists()) {
            throw new NotFoundHttpException();
        }

        // Update the game and redirect
        $game->update($request->validated());
        return redirect('/admin');
    }

    /**
     * Show game score edit
     */
    public function editGameScore(Game $game, Score $score)
    {
        // Check whether the user has access to the game
        if(!DB::table('game_users')->where('game_id', $game->id)->where('user_id', auth()->user()->id)->exists()) {
            throw new NotFoundHttpException();
        }

        return view('not-admin.scores.edit', compact('game', 'score'));
    }

    /**
     * Update game score
     */
    public function updateGameScore(StoreGameScoreRequest $request, Game $game, Score $score)
    {
        // Check whether the user has access to the game
        if(!DB::table('game_users')->where('game_id', $game->id)->where('user_id', auth()->user()->id)->exists()) {
            throw new NotFoundHttpException();
        }

        // Update and redirect
        $score->update($request->validated());
        return redirect('/admin');
    }

    /**
     * Show game score create
     */
    public function createGameScore(Game $game)
    {
        // Check whether the user has access to the game
        if(!DB::table('game_users')->where('game_id', $game->id)->where('user_id', auth()->user()->id)->exists()) {
            throw new NotFoundHttpException();
        }

        return view('not-admin.scores.create', compact('game'));
    }

    /**
     * Show game score create
     */
    public function storeGameScore(StoreGameScoreRequest $request, Game $game)
    {
        // Check whether the user has access to the game
        if(!DB::table('game_users')->where('game_id', $game->id)->where('user_id', auth()->user()->id)->exists()) {
            throw new NotFoundHttpException();
        }

        Score::create($request->validated() + ['game_id' => $game->id]);
        return redirect('/admin');
    }
}
