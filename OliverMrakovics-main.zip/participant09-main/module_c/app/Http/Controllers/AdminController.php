<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Game;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    /**
     * Route that serves the /admin route
     */
    public function index(Request $request)
    {
        // Check whether the user is admin or not
        if(auth()->user()->admin) {
            return view('admin.index', ['users' => User::all(), 'games' => Game::all()]);
        }

        // Normal user
        return view(
            'not-admin.index',
            [
                'games' => Game::whereIn('id', DB::table('game_users')->where('user_id', auth()->user()->id)->select('game_id'))->with('scores')->get()
            ]
        );
    }
}
