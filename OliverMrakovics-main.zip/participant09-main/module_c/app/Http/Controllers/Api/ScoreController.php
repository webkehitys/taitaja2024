<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreGameScoreRequest;
use App\Models\Game;
use App\Models\Score;
use Illuminate\Http\Request;

class ScoreController extends Controller
{
    /**
     * Create a game score in the database
     */
    public function store(StoreGameScoreRequest $request, Game $game)
    {
        // Create a game score
        return Score::create($request->validated() + ['game_id' => $game->id]);
    }
}
