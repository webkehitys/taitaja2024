<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\LoginRequest;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    /**
     * Login action
     */
    public function login(LoginRequest $request)
    {
        // Find a user with the username
        $user = User::where('username', $request->username)->first();
        if(!$user) {
            return back()->withErrors(['auth' => 'Invalid credentials'])->withInput();
        }

        // Check the pw
        if(!Hash::check($request->password, $user->password)) {
            return back()->withErrors(['auth' => 'Invalid credentials'])->withInput();
        }

        // Successful login
        auth()->login($user);
        return redirect(RouteServiceProvider::HOME);
    }

    /**
     * Logout route
     */
    public function logout()
    {
        // Logout and redirect
        auth()->logout();
        return redirect('/login');
    }
}
