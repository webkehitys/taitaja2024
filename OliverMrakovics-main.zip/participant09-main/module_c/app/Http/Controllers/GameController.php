<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\AddUserToGameRequest;
use App\Http\Requests\StoreGameRequest;
use App\Http\Requests\UpdateGameRequest;
use App\Models\Game;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GameController extends Controller
{
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('games.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreGameRequest $request)
    {
        // DTO
        $dto = $request->validated();

        // Upload the image if any
        if ($request->has('image')) {
            $file = $request->file('image');
            $file->move(public_path(), $file->getClientOriginalName());
            $dto['image'] = $file->getClientOriginalName();
        }

        // Create the game
        Game::create($dto);
        return redirect('/admin');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Game $game)
    {
        return view('games.edit', ['game' => $game]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateGameRequest $request, Game $game)
    {
        // DTO
        $dto = $request->validated();

        // Upload the image if any
        if ($request->has('image')) {
            $file = $request->file('image');
            if (!str_ends_with($game->image, $file->getClientOriginalName())) {
                $file->move(public_path(), $file->getClientOriginalName());
                $dto['image'] = $file->getClientOriginalName();
            }
        }

        // update the game and return
        $game->update($dto);
        return redirect('/admin');
    }

    /**
     * Route for adding users in that game
     */
    public function users(Game $game)
    {
        return view(
            'games.users',
            [
                'users' => User::whereIn('id', DB::table('game_users')->where('game_id', $game->id)->select('user_id'))->get(),
                'game' => $game
            ]
        );
    }

    /**
     * Function for adding a user to the game
     */
    public function addUser(AddUserToGameRequest $request, Game $game)
    {
        // Find the user
        $user = User::where('username', $request->username)->first();

        // Get it any exists
        if(DB::table('game_users')->where('game_id', $game->id)->where('user_id', $user->id)->exists()) {
            return back()->withInput()->withErrors(['username' => 'This user is already part of the game!']);
        }

        DB::table('game_users')->insert(['user_id' => $user->id, 'game_id' => $game->id]);
        return redirect('/games/' . $game->id . '/users');
    }
}
