# WPM-laskuri

Luo yksinkertainen verkkosovellus, joka mittaa käyttäjän kirjoitusnopeuden satunnaisen syötteen perusteella.

**Odotettu lopputulos:**

- Kun käyttäjä alkaa kirjoittaa tekstialueelle, ajastin käynnistyy.
- 60 sekunnin kuluttua testi päättyy automaattisesti ja sovellus laskee kirjoitusnopeuden WPM.
- Tulokset (WPM) näytetään yhdessä kuluneen ajan kanssa.
