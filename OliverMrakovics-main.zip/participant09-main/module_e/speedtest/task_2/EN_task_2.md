# WPM counter

Create a simple web application that measures the typing speed of a user based on their random input.

**Expected outcome:**

- When the user starts typing in the text area, a timer begins.
- After 60 seconds, the test ends automatically, and the application calculates the typing speed in WPM.
- The result (WPM) is displayed along with the elapsed time.
