# Palautelomake

Kehitä turvallinen palautesivu, jossa käyttäjät voivat ehdottaa pelitapahtumaa ja pelejä, joita tapahtumassa pelataan. Lähetetty palaute tulisi lähettää osoitteeseen info@webkehitys.fi. Toteuta helppo CAPTCHA, joka pyytää käyttäjää ratkaisemaan summan kahdesta satunnaisesta numerosta välillä 0–9.

**Palautelomakkeen kentät:**

- Nimi
- Sähköposti
- Ehdota nimeä pelitapahtumalle
- Päivämäärä ja aika
- Mitä pelejä tapahtumassa tulisi pelata?

Lähetyksen jälkeen lomake tyhjennetään ja käyttäjälle ilmoitetaan onnistuneesta lähetyksestä.
