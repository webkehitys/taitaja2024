# Feedback form

Develop a secure feedback page where users can suggest a gaming event and the games to be played. Submitted feedback should be sent to info@webkehitys.fi. Implement an easy CAPTCHA that asks the user to solve a sum of two random numbers between 0 and 9.

**Feedback Form Fields:**

- Name
- Email
- Suggest a name for the game event
- Date and time
- Which games should be played at the event?

After submission, the form is reset and the user is notified of the successful submission.
