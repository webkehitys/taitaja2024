# Debugging

Fix all bugs in the provided HTML and JavaScript code to get the form working correctly. Use the screenshot as an example of the working solution.
