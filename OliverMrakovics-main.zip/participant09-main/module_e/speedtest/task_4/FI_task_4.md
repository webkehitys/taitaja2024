# Debugging

Korjaa kaikki annetun HTML- ja JavaScript-koodin virheet, jotta lomake toimii oikein. Käytä ruutukaappausta esimerkkinä toimivasta ratkaisusta.
