# Käyttäjänimigeneraattori

Luo verkkosovellus, joka generoi satunnaisia käyttäjänimiä pelaajille yhdistämällä käyttäjän antaman etuliitteen satunnaiseen jälkiliitteeseen (suffix.js-tiedostosta).

- Käyttäjät syöttävät etuliitteen syöttökenttään.
- Käyttäjät klikkaavat generoi-painiketta luodakseen satunnaisen käyttäjänimen.
- Näytetään generoitu käyttäjänimi, joka yhdistää käyttäjän etuliitteen listasta valittuun satunnaiseen jälkiliitteeseen.
- Käyttäjät voivat klikata painiketta kopioidakseen generoidun käyttäjänimen leikepöydälle.

**Esimerkki**

- Käyttäjä syöttää etuliitteeksi "Cool".
- Käyttäjä klikkaa "Generoi käyttäjänimi" -painiketta.
- Käyttäjänimi "CoolDragon" näytetään sulavalla skaalausanimaatiolla.
- Käyttäjä klikkaa "Kopioi leikepöydälle" -painiketta, ja ilmoitus vahvistaa, että käyttäjänimi on kopioitu.
