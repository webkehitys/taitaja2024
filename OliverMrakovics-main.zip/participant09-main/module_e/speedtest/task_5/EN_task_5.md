# Tic-Tac-Toe

Finalize the CSS for a web page according to a given video example.
Do not modify the HTML and JavaScript files.
