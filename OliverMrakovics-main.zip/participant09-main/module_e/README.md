# Moduuli E - Pikataival

**Tehtävään käytettävä kilpailuaika: 1h**

Sinulla on useita erillisiä tehtäviä ratkaistavana tässä moduulissa. Tehtävät vaihtelevat vaikeustasoltaan, ja voit valita, missä järjestyksessä ne ratkaiset. Päämääränä on ratkaista mahdollisimman monta tehtävää. Toimita ratkaisusi annettuun ratkaisukansioon (`solution`).

**HUOM:** internetin käyttö ei ole sallittua tämän moduulin aikana

**Moduulin lopussa on toimitettava:**

- mahdollisimman paljon tehtäviä annetuista tehtävistä
