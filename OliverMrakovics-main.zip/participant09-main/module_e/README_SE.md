# Modul E - Hastighetstest

**Tävlingstid för uppgiften: 1h**

Du har flera separata uppgifter att lösa i denna modul. Uppgifterna varierar i svårighetsgrad, och du kan välja i vilken ordning du löser dem. Målet är att lösa så många uppgifter som möjligt. Skicka dina lösningar till den angivna lösningsmappen (`solution`).

**OBS:** internetanvändning är inte tillåten under denna modul

**I slutet av modulen måste du lämna in:**

- Så många uppgifter som möjligt från de givna uppgifterna.
