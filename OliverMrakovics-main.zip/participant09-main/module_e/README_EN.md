# Module E - Speedtest

**Competition time for the task: 1 hours**

You have several separate tasks to solve in this module. The tasks vary in difficulty, and you can choose the order in which you solve them. The goal is to solve as many tasks as possible. Submit your solutions to the provided `solution` folder.

**NOTE:** internet usage is not allowed during this module

**At the end of the module, you must submit:**

- As many tasks as possible from the given tasks.
