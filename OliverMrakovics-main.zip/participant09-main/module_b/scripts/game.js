"use strict";

// Define the variables
const gameName = document.getElementById("game-name");
const scoresTableContent = document.getElementById("scores-table-content");
const searchInput = document.getElementById("search");

let game = null;
let searchValue = "";

// Function calls
(async () => {
  await fetchGames();
})();

// Update the search value
let timeout;
searchInput.oninput = (e) => {
  clearTimeout(timeout);

  timeout = setTimeout(() => {
    searchValue = e.target.value.toLowerCase();
    renderGameScores();
  }, 300);
};

// Function for fetching the games
async function fetchGames() {
  const res = await fetch("/games.json");
  const json = await res.json();
  game = json.games.find((x) => x.ID === 1);
  game.hall_of_fame = game.hall_of_fame
    .sort((a, z) => z.score - a.score)
    .map((item, idx) => ({ ...item, rank: idx }));

  renderGameName();
  renderGameScores();
}

// Function for displaying the header
function renderGameName() {
  gameName.innerText = game.game_name.en.toUpperCase();
}

// Function for rendering the game scores
function renderGameScores() {
  let scores = game.hall_of_fame;

  // Filter the scores based on username
  if (searchValue) {
    scores = scores.filter((x) =>
      x.username.toLowerCase().includes(searchValue)
    );
  }

  let innerHTML = "";

  // Create the innerHTML
  for (const item of scores.slice(0, 20)) {
    innerHTML += `
      <tr
        style="white-space:nowrap; background-color: ${
          item.rank === 0
            ? "#304BFFbb"
            : item.rank === 1
            ? "#304BFF88"
            : item.rank === 2
            ? "#304BFF55"
            : "white"
        }; font-weight: ${item.rank < 3 ? "600" : "400"}"
      >
        <td>
          ${item.rank + 1}
          ${item.rank === 0 ? "🥇" : ""}
          ${item.rank === 1 ? "🥈" : ""}
          ${item.rank === 2 ? "🥉" : ""}
          </td>
        <td>${item.username}</td>
        <td>${item.score}</td>
        <td style="text-align: right">${new Date(item.date_time).toLocaleString(
          "fi-FI"
        )}</td>
      </tr>
    `;
  }

  if (scores.length < 1) {
    innerHTML =
      '<tr><td colspan="5" style="text-align:center;">No users found. 😭</td></tr>';
  }

  scoresTableContent.innerHTML = innerHTML;
}
