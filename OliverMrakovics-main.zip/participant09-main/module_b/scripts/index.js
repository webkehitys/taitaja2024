"use strict";

// Define the variables
const gamesContainer = document.getElementById("games-container");
const searchInput = document.getElementById("search");
const paginationContainer = document.getElementById("pagination");

const ITEMS_PER_PAGE = 20;
let currentPage = 1;
let totalPages = 1;
let games = [];
let filteredGames = [];

// Function calls
(async () => {
  await fetchGames();
})();

// Handle the search functionality
let timeout;
searchInput.oninput = (e) => {
  clearTimeout(timeout);

  timeout = setTimeout(() => {
    currentPage = 1;
    const searchValue = e.target.value.toLowerCase().trim();

    if (!searchValue) {
      filteredGames = structuredClone(games);
    } else {
      filteredGames = structuredClone(games).filter((x) =>
        x.game_name.en.toLowerCase().includes(searchValue)
      );
    }

    totalPages = Math.ceil(filteredGames.length / ITEMS_PER_PAGE);
    renderGames();
    renderPagination(totalPages, currentPage);
  }, 300);
};

// Function for fetching the games
async function fetchGames() {
  const res = await fetch("/games.json");
  const json = await res.json();
  games = json.games.sort(
    (a, z) =>
      new Date(z.added_to_hall_of_fame) - new Date(a.added_to_hall_of_fame)
  );

  if (!searchInput.value) {
    filteredGames = structuredClone(games);
  } else {
    filteredGames = structuredClone(games).filter((x) =>
      x.game_name.en.toLowerCase().includes(searchInput.value.toLowerCase())
    );
  }
  totalPages = Math.ceil(filteredGames.length / ITEMS_PER_PAGE);

  renderPagination(totalPages, currentPage);
  renderGames();
}

// Function for rendering the pagination
function renderPagination(totalPages, currentPage) {
  if (filteredGames.length <= 20) {
    paginationContainer.innerHTML = "";
    return;
  }

  let innerHTML = "";
  innerHTML += `
    <button
      onclick="changePage(${currentPage - 1})"
      class="btn primary-outlined"
      ${currentPage === 1 ? "disabled" : ""}
    >
      &lt;
    </button>`;

  for (let i = 1; i <= totalPages; i++) {
    innerHTML += `
      <button
        class="btn primary-outlined ${i === currentPage ? "selected" : ""}"
        onclick="changePage(${i})"
      >
        ${i}
      </button>`;
  }

  innerHTML += `
    <button
      onclick="changePage(${currentPage + 1})"
      class="btn primary-outlined"
      ${currentPage === totalPages ? "disabled" : ""}
    >
      &gt;
    </button>`;
  paginationContainer.innerHTML = innerHTML;
}

// Function for rendering the games
function renderGames() {
  let innerHTML = "";

  for (const game of filteredGames.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  )) {
    const winner = game.hall_of_fame.sort((a, z) => z.score - a.score).at(0);

    innerHTML += `
      <a class="game-card" href="/game.html">
        <img src="/assets/game-img.jpeg" alt="${game.game_name.en}" />
        <span style="font-weight: 600">${game.game_name.en}</span>
        <ul>
          <li>Winner: <span class="font-semibold">${winner.username}</span></li>
          <li>Score: <span class="font-semibold">${winner.score}</span></li>
        </ul>
      </a>
  `;
  }

  if (filteredGames.length < 1) {
    innerHTML = "<div>No games found.</div>";
  }

  gamesContainer.innerHTML = innerHTML;
}

// Function for changing page
function changePage(newPage) {
  currentPage = newPage;
  renderGames();
  renderPagination(totalPages, newPage);
}
