// Get the entries that need animating
const entriesToAnimate = document.querySelectorAll("[data-animate]");

// Set their animation delay
entriesToAnimate.forEach((e) => {
  e.style.animationDelay = `${e.dataset.animate || 0}ms`;
});

// Create an intersection observer to trigger the animations
const observer = new IntersectionObserver((entries) => {
  entries.forEach((e) => {
    if (e.isIntersecting) {
      e.target.classList.add("animate");
    }
  });
});
entriesToAnimate.forEach((e) => observer.observe(e));
