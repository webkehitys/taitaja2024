import { RouterProvider, createBrowserRouter } from "react-router-dom";
import MainLayout from "./components/layout/MainLayout";
import GameIndex from "./components/game/GameIndex";

/**
 * Create the router
 */
const router = createBrowserRouter([
  {
    element: (
      <MainLayout>
        <GameIndex />
      </MainLayout>
    ),
    path: "*",
  },
]);

/**
 * The entrypoint of the application
 */
const App = () => {
  return <RouterProvider router={router} />;
};

export default App;
