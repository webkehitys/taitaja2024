/**
 * Component for starting the game
 */
const StartGame = ({ onStart, success }) => {
  return (
    <div className="start-game-container">
      {success && <span>Your score has been saved successfully!</span>}
      <button onClick={onStart}>Start Game</button>
    </div>
  );
};

export default StartGame;
