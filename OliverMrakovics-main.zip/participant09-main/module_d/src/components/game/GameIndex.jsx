import { useCallback, useEffect, useState } from "react";
import {
  GAME_HEIGHT,
  GAME_WIDTH,
  INITIAL_SNAKE_ONE,
  INITIAL_SNAKE_TWO,
  INTERVAL,
  directionOffset,
} from "../../const";
import { useSnakeOneDirection } from "../../hooks/useSnakeOneDirection";
import { useSnakeTwoDirection } from "../../hooks/useSnakeTwoDirection";
import Game from "./Game";
import GameScore from "./GameScore";
import StartGame from "./StartGame";
import GameEnd from "./GameEnd";
import { useMoveSnakes } from "../../hooks/useMoveSnakes";
import { useUpdateSnakeDirections } from "../../hooks/useUpdateSnakeDirections";
import { useCreateApples } from "../../hooks/useCreateApples";

/**
 * The entrypoint of our game
 */
const GameIndex = () => {
  /**
   * Keep the important state
   */
  const [gameStarted, setGameStarted] = useState(false);
  const [gameEnd, setGameEnd] = useState(false);
  const [score, setScore] = useState(0);
  const [success, setSuccess] = useState(false);

  const [snakeOneDirection, setSnakeOneDirection] =
    useSnakeOneDirection(gameStarted);
  const [snakeOne, setSnakeOne] = useState(structuredClone(INITIAL_SNAKE_ONE));

  const [snakeTwoDirection, setSnakeTwoDirection] =
    useSnakeTwoDirection(gameStarted);
  const [snakeTwo, setSnakeTwo] = useState(structuredClone(INITIAL_SNAKE_TWO));

  const [apple, setApple] = useState({
    x: Math.floor(Math.random() * GAME_WIDTH),
    y: Math.floor(Math.random() * GAME_HEIGHT),
  });

  /**
   * End game
   */
  const endGame = useCallback(() => {
    setGameEnd(true);
    setGameStarted(false);
  }, []);

  /**
   * Handle the game over state
   */
  const restartGame = useCallback(() => {
    setGameStarted(false);
    setGameEnd(false);
    setScore(0);
    setSnakeOneDirection("RIGHT");
    setSnakeTwoDirection("RIGHT");
    setSnakeOne(structuredClone(INITIAL_SNAKE_ONE));
    setSnakeTwo(structuredClone(INITIAL_SNAKE_TWO));
    setApple({
      x: Math.floor(Math.random() * GAME_WIDTH),
      y: Math.floor(Math.random() * GAME_HEIGHT),
    });
  }, []);

  /**
   * Move the snakes
   */
  useMoveSnakes(
    gameStarted,
    setSnakeOne,
    snakeOneDirection,
    setSnakeTwo,
    snakeTwoDirection
  );

  /**
   * Update the snakes' directions
   */
  useUpdateSnakeDirections(
    gameStarted,
    setSnakeOne,
    snakeOneDirection,
    setSnakeTwo,
    snakeTwoDirection
  );

  /**
   * Create apples
   */
  useCreateApples(gameStarted, setApple);

  /**
   * Check the first snake collision with the apple
   */
  useEffect(() => {
    if (!gameStarted) return;

    const interval = setInterval(() => {
      setSnakeOne((prevSnake) => {
        if (!apple) return prevSnake;

        const first = prevSnake[0];

        if (first.x === apple.x && apple.y === first.y) {
          setApple(null);
          setScore((s) => s + 1);
          const last = prevSnake.at(-1);
          const offset =
            directionOffset[last.direction] ??
            directionOffset[snakeOneDirection];
          const newX = last.x - offset[0];
          const newY = last.y - offset[1];
          return [
            ...prevSnake,
            {
              x: newX,
              y: newY,
              next: structuredClone(last),
              direction: last.direction,
            },
          ];
        }

        return prevSnake;
      });
    }, INTERVAL);

    return () => clearInterval(interval);
  }, [apple, snakeOneDirection, gameStarted]);

  /**
   * Check the second snake collision with the apple
   */
  useEffect(() => {
    if (!gameStarted) return;

    const interval = setInterval(() => {
      setSnakeTwo((prevSnake) => {
        if (!apple) return prevSnake;

        const first = prevSnake[0];

        if (first.x === apple.x && apple.y === first.y) {
          setApple(null);
          setScore((s) => s + 1);
          const last = prevSnake.at(-1);
          const offset =
            directionOffset[last.direction] ??
            directionOffset[snakeTwoDirection];
          const newX = last.x - offset[0];
          const newY = last.y - offset[1];
          return [
            ...prevSnake,
            {
              x: newX,
              y: newY,
              next: structuredClone(last),
              direction: last.direction,
            },
          ];
        }

        return prevSnake;
      });
    }, INTERVAL);

    return () => clearInterval(interval);
  }, [apple, snakeTwoDirection, gameStarted]);

  /**
   * Check whether the snake ate himself
   */
  useEffect(() => {
    if (!gameStarted) return;

    const coords = [...snakeOne, ...snakeTwo];

    for (const i of coords) {
      if (coords.filter((j) => j.x === i.x && j.y === i.y).length > 1) {
        endGame();
      }
    }
  }, [snakeOne, snakeTwo, endGame, gameStarted]);

  return (
    <div className="game-container">
      <GameScore score={score} />
      <div className="game-main">
        {gameEnd ? (
          <GameEnd
            onNo={restartGame}
            score={score}
            onSuccess={() => {
              restartGame();
              setSuccess(true);
            }}
          />
        ) : gameStarted ? (
          <Game snakeOne={snakeOne} apple={apple} snakeTwo={snakeTwo} />
        ) : (
          <StartGame onStart={() => setGameStarted(true)} success={success} />
        )}
      </div>
    </div>
  );
};

export default GameIndex;
