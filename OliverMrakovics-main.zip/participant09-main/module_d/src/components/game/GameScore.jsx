/**
 * Component for displaying the game scores
 * @returns
 */
const GameScore = ({ score }) => {
  return (
    <div className="game-score">SCORE: {score.toString().padStart(3, "0")}</div>
  );
};

export default GameScore;
