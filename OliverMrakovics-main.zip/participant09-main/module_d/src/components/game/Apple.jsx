/**
 * Component for displaying an apple
 */
const Apple = () => {
  return (
    <div className="game-item snake-part">
      <div style={{ background: "transparent" }} />
      <div style={{ background: "transparent" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "transparent" }} />
      <div style={{ background: "transparent" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "transparent" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "black" }} />
      <div style={{ background: "transparent" }} />
    </div>
  );
};

export default Apple;
