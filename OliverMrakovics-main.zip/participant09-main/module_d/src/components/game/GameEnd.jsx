import { useState } from "react";

/**
 * Component for displaying the game end stuff
 */
const GameEnd = ({ onNo, score, onSuccess }) => {
  const [yesClicked, setYesClicked] = useState(false);
  const [username, setUsername] = useState("");

  /**
   * Send the score to the backend
   */
  async function handleSubmit(e) {
    e.preventDefault();
    if (!username) return;

    await fetch("https://module-c.3418.sollertis.host/api/games/1/score", {
      method: "POST",
      body: JSON.stringify({ username, score }),
      headers: { "Content-Type": "application/json" },
    });

    onSuccess();
  }

  return (
    <div className="end-game-container">
      <h1 style={{ fontSize: "1.8rem" }}>GAME OVER!</h1>
      <h2>Do you want to save the score?</h2>
      {yesClicked ? (
        <form onSubmit={handleSubmit} className="score-form">
          <input
            placeholder="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
          <button style={{ alignSelf: "center" }}>Submit</button>
        </form>
      ) : (
        <div className="row">
          <button onClick={onNo}>No</button>
          <button onClick={() => setYesClicked(true)}>Yes</button>
        </div>
      )}
    </div>
  );
};

export default GameEnd;
