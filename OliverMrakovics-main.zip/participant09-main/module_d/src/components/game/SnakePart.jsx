import React from "react";

const directionRotate = {
  RIGHT: 0,
  DOWN: 90,
  LEFT: 180,
  TOP: 270,
};

/**
 * Component that displays one snake part
 */
const SnakePart = ({ direction, isHead, isTail }) => {
  return (
    <div
      className="game-item snake-part"
      style={{ transform: `rotate(${directionRotate[direction]}deg)` }}
    >
      {isHead ? (
        <>
          <div style={{ background: "transparent" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "transparent" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "transparent" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
        </>
      ) : isTail ? (
        <>
          <div style={{ background: "transparent" }} />
          <div style={{ background: "transparent" }} />
          <div style={{ background: "transparent" }} />
          <div style={{ background: "transparent" }} />
          <div style={{ background: "transparent" }} />
          <div style={{ background: "transparent" }} />
          <div style={{ background: "transparent" }} />
          <div style={{ background: "transparent" }} />
          <div style={{ background: "transparent" }} />
          <div style={{ background: "transparent" }} />
          <div style={{ background: "transparent" }} />
          <div style={{ background: "transparent" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
        </>
      ) : (
        <>
          <div style={{ background: "transparent" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "black" }} />
          <div style={{ background: "transparent" }} />
        </>
      )}
    </div>
  );
};

export default SnakePart;
