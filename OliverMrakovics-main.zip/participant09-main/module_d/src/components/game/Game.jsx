import Apple from "./Apple";
import SnakePart from "./SnakePart";
import { GAME_HEIGHT, GAME_WIDTH } from "../../const";

/**
 * Component for holding the actual game, rendering the grid
 */
const Game = ({ snakeOne, apple, snakeTwo }) => {
  return Array.from({ length: GAME_HEIGHT })
    .fill("")
    .map((_, y) => (
      <div key={y} className="game-row">
        {Array.from({ length: GAME_WIDTH })
          .fill("")
          .map((_, x) => {
            // Check whether the first snake here
            const foundSnakeOneIdx = snakeOne.findIndex(
              (s) => s.x === x && s.y === y
            );
            const isOneHead = foundSnakeOneIdx === 0;
            const isOneTail = foundSnakeOneIdx === snakeOne.length - 1;

            // If it is, render a snake part
            if (foundSnakeOneIdx !== -1) {
              return (
                <SnakePart
                  key={`${x}-${y}`}
                  isHead={isOneHead}
                  isTail={isOneTail}
                  direction={snakeOne[foundSnakeOneIdx].direction}
                />
              );
            }

            // Check whether the second snake here
            const foundSnakeTwoIndex = snakeTwo.findIndex(
              (s) => s.x === x && s.y === y
            );
            const isTwoHead = foundSnakeTwoIndex === 0;
            const isTwoTail = foundSnakeTwoIndex === snakeTwo.length - 1;

            // If it is, render a snake part
            if (foundSnakeTwoIndex !== -1) {
              return (
                <SnakePart
                  key={`${x}-${y}`}
                  isHead={isTwoHead}
                  isTail={isTwoTail}
                  direction={snakeTwo[foundSnakeTwoIndex].direction}
                />
              );
            }

            // Check whether it is an apple
            if (apple && apple.x === x && apple.y == y) {
              return <Apple key={`${x}-${y}`} />;
            }

            return <div className="game-item" key={`${x}-${y}`}></div>;
          })}
      </div>
    ));
};

export default Game;
