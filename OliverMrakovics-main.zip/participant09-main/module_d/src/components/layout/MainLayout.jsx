import React from "react";

/**
 * Layout for the entire application
 */
const MainLayout = ({ children }) => {
  return <div className="layout">{children}</div>;
};

export default MainLayout;
