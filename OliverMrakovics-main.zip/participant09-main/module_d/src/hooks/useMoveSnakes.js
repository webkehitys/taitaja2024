import { useEffect } from "react";
import { GAME_HEIGHT, GAME_WIDTH, INTERVAL, directionOffset } from "../const";

/**
 *  Hook that moves the snakes
 */
export function useMoveSnakes(
  gameStarted,
  setSnakeOne,
  snakeOneDirection,
  setSnakeTwo,
  snakeTwoDirection
) {
  useEffect(() => {
    if (!gameStarted) return;

    /**
     * First snake
     */
    const firstInterval = setInterval(() => {
      setSnakeOne((prev) => {
        const next = prev.map((curr, idx, arr) => {
          const offset = directionOffset[curr.next.direction];
          const newX = (curr?.next?.x ?? curr.x) + offset[0];
          const newY = (curr?.next?.y ?? curr.y) + offset[1];

          return {
            ...curr.next,
            next: {
              direction: arr[idx - 1]?.next?.direction ?? snakeOneDirection,
              x: newX >= GAME_WIDTH ? 0 : newX < 0 ? GAME_WIDTH : newX,
              y: newY >= GAME_HEIGHT ? 0 : newY < 0 ? GAME_HEIGHT : newY,
            },
          };
        });

        return next;
      });
    }, INTERVAL);

    /**
     * Second snake
     */
    const secondInterval = setInterval(() => {
      setSnakeTwo((prev) => {
        const next = prev.map((curr, idx, arr) => {
          const offset = directionOffset[curr.next.direction];
          const newX = (curr?.next?.x ?? curr.x) + offset[0];
          const newY = (curr?.next?.y ?? curr.y) + offset[1];

          return {
            ...curr.next,
            next: {
              direction: arr[idx - 1]?.next?.direction ?? snakeTwoDirection,
              x: newX >= GAME_WIDTH ? 0 : newX < 0 ? GAME_WIDTH : newX,
              y: newY >= GAME_HEIGHT ? 0 : newY < 0 ? GAME_HEIGHT : newY,
            },
          };
        });

        return next;
      });
    }, INTERVAL);

    return () => {
      clearInterval(firstInterval);
      clearInterval(secondInterval);
    };
  }, [snakeOneDirection, snakeTwoDirection, gameStarted]);
}
