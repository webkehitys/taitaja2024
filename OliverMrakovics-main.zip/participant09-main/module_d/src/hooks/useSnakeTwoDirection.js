import { useEffect, useState } from "react";

/**
 * Function for using the WASD to navigate the first snake
 */
export function useSnakeTwoDirection(gameStarted) {
  const [snakeTwoDirection, setSnakeTwoDirection] = useState("RIGHT");

  /**
   * Event handler for the WASD
   */
  useEffect(() => {
    if (!gameStarted) return;

    function handleKeyDown(e) {
      switch (e.key) {
        case "ArrowUp":
          setSnakeTwoDirection("TOP");
          break;
        case "ArrowLeft":
          setSnakeTwoDirection("LEFT");
          break;
        case "ArrowDown":
          setSnakeTwoDirection("DOWN");
          break;
        case "ArrowRight":
          setSnakeTwoDirection("RIGHT");
          break;
      }
    }

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [gameStarted]);

  return [snakeTwoDirection, setSnakeTwoDirection];
}
