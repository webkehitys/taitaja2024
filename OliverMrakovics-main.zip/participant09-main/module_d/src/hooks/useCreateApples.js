import { useEffect } from "react";
import { GAME_HEIGHT, GAME_WIDTH } from "../const";

/**
 * Hook that creates apples nonstop
 */
export function useCreateApples(gameStarted, setApple) {
  /**
   * Create apples randomly
   */
  useEffect(() => {
    if (!gameStarted) return;

    const interval = setInterval(() => {
      setApple((prev) => {
        if (prev) return prev;

        return {
          x: Math.floor(Math.random() * GAME_WIDTH),
          y: Math.floor(Math.random() * GAME_HEIGHT),
        };
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [gameStarted]);
}
