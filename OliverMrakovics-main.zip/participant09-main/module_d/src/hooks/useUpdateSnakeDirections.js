import { useEffect } from "react";

/**
 * Hook for updating the snakes' directions
 */
export function useUpdateSnakeDirections(
  gameStarted,
  setSnakeOne,
  snakeOneDirection,
  setSnakeTwo,
  snakeTwoDirection
) {
  /**
   * Update the direction for the first snake
   */
  useEffect(() => {
    if (!gameStarted) return;

    setSnakeOne((prev) => {
      prev[0] = {
        ...prev[0],
        next: { ...prev[0].next, direction: snakeOneDirection },
      };
      return prev;
    });
  }, [snakeOneDirection, gameStarted]);

  /**
   * Update the direction for the second snake
   */
  useEffect(() => {
    if (!gameStarted) return;

    setSnakeTwo((prev) => {
      prev[0] = {
        ...prev[0],
        next: { ...prev[0].next, direction: snakeTwoDirection },
      };
      return prev;
    });
  }, [snakeTwoDirection, gameStarted]);
}
