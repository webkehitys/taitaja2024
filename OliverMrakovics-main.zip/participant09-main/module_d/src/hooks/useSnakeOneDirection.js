import { useEffect, useState } from "react";

/**
 * Function for using the WASD to navigate the first snake
 */
export function useSnakeOneDirection(gameStarted) {
  const [snakeOneDirection, setSnakeOneDirection] = useState("RIGHT");

  /**
   * Event handler for the WASD
   */
  useEffect(() => {
    if (!gameStarted) return;

    function handleKeyDown(e) {
      switch (e.key.toLowerCase()) {
        case "w":
          setSnakeOneDirection("TOP");
          break;
        case "a":
          setSnakeOneDirection("LEFT");
          break;
        case "s":
          setSnakeOneDirection("DOWN");
          break;
        case "d":
          setSnakeOneDirection("RIGHT");
          break;
      }
    }

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [gameStarted]);

  return [snakeOneDirection, setSnakeOneDirection];
}
