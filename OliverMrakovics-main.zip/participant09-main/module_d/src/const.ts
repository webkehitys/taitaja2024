/**
 * Define some constants
 */
export const GAME_HEIGHT = 20;
export const GAME_WIDTH = 38;

export const INTERVAL = 150;

export const directionOffset = {
  LEFT: [-1, 0],
  RIGHT: [1, 0],
  TOP: [0, -1],
  DOWN: [0, 1],
};

/**
 * They are the snakes in their initial position
 */
export const INITIAL_SNAKE_ONE = [
  { x: 9, y: 2, direction: "RIGHT", next: { x: 10, y: 2, direction: "RIGHT" } },
  { x: 8, y: 2, direction: "RIGHT", next: { x: 9, y: 2, direction: "RIGHT" } },
  { x: 7, y: 2, direction: "RIGHT", next: { x: 8, y: 2, direction: "RIGHT" } },
  { x: 6, y: 2, direction: "RIGHT", next: { x: 7, y: 2, direction: "RIGHT" } },
  { x: 5, y: 2, direction: "RIGHT", next: { x: 6, y: 2, direction: "RIGHT" } },
];
export const INITIAL_SNAKE_TWO = [
  {
    x: 9,
    y: 17,
    direction: "RIGHT",
    next: { x: 10, y: 17, direction: "RIGHT" },
  },
  {
    x: 8,
    y: 17,
    direction: "RIGHT",
    next: { x: 9, y: 17, direction: "RIGHT" },
  },
  {
    x: 7,
    y: 17,
    direction: "RIGHT",
    next: { x: 8, y: 17, direction: "RIGHT" },
  },
  {
    x: 6,
    y: 17,
    direction: "RIGHT",
    next: { x: 7, y: 17, direction: "RIGHT" },
  },
  {
    x: 5,
    y: 17,
    direction: "RIGHT",
    next: { x: 6, y: 17, direction: "RIGHT" },
  },
];