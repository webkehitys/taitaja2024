# Oliver Mrakovics - Taitaja 2024

## Modules

### Module A

The files for this module is available under the `module_a` folder.  
The wireframes are in the `module_a/assets/wireframes` folder as PNGs. Also, I provided a Figma file as well.  
The documentation is in the `module_a` folder, in both PDF and DOCX formats.

---

### Module B

The source code for this module is available under the `module_b` folder.  
Technologies used: HTML, CSS, JS - No frameworks or libraries.  
The deployed version of this module is available under this URL: [http://module-b.3418.sollertis.host](http://module-b.3418.sollertis.host). Please try it in incognito mode.

---

### Module C

The source code for this module is available under the `module_c` folder.
Technologies used: Laravel.

#### How to access the intranet

The intranet should be available under the following URL: [https://module-c.3418.sollertis.host/admin](https://module-c.3418.sollertis.host/admin). If not, or something weird happens, please refer to the next paragraph.

#### Building from scratch

After cloning the repository, cd into the `module_c` folder. Run the `composer install` command. (Installing composer is needed!)  
Setup a MySQL database (for example using XAMPP), and create a database called `intranet`. Create the initial tables and records using the dump I provided in the `module_c/intranet.sql` file.  
After everything is set up, run the `php artisan serve` command. The intranet should be accessible in the [http://localhost:8000/admin](http://localhost:8000/admin) url.

#### How to use the intranet

When the user first visits the page, he/she will be redirected to the login page. After logging in, the admin panel is shown, which is different for admin and different for user users.

There is two initial users in the database:

- admin, taitaja2024
- user, taitaja2024

The normal user has the following sections:

- A form for updating their own password
- Multiple records of games mapped in a single page.
  - Each game consist of three sections:
    - A form where the user can update the number of resutls displayed in the hall of fame
    - A table where the user can see the participants and their scores. Also, this table contains an edit button.
    - And a button for creating a new score.

The admin user has the following:

- One table for the users. The table contains username, created_at, role, and actions buttons for updating and deleting the user.
- The second table is for the games. It also has an edit button. The image is shown as well (if the game has image)
  - Clicking on the Manage users button, a new UI appears. Here, the admin can see in a table what users have permission to edit the game. Also, they can add users to this game using the form below the table.
- The admin panel also contains buttons for creating new user or game.

---

### Module D

The source code for this module is available under the `module_d` folder.
Technologies used: React.

The deployed site is available under the following URL: [https://module-d.3418.sollertis.host/games/snakegame](https://module-d.3418.sollertis.host/games/snakegame)
